/**
 * background.js — Service worker (MV3), nay là ROUTER thuần.
 *
 * Vai trò:
 *  - Là nơi DUY NHẤT sở hữu IndexedDB của extension (qua db.js).
 *  - Trung gian message giữa content script, popup và dashboard.
 *  - Lập lịch chạy job + tự động crawl/sync nền qua chrome.alarms.
 *
 * Sau bước tách module (B3): logic nghiệp vụ nằm ở các module domain:
 *  - util.js     : helper dùng chung (tab/DOM, fetch, parse, decode...).
 *  - db.js       : toàn bộ truy cập IndexedDB (import * as DB).
 *  - prices.js   : nguồn giá bán lẻ + seed + đồng bộ sản phẩm.
 *  - sheets.js   : "Kho của tôi" (nhập từ Google Sheet công khai).
 *  - ai.js       : khám phá selector + build cấu hình bằng AI + list model.
 *  - advisory.js : tư vấn AI (phân loại ý định, soạn nháp, duyệt gửi).
 *  - crawl.js    : crawl theo nhóm/hàng loạt, job đăng bài/bình luận,
 *                  auto-crawl + auto-sync nền.
 *
 * File này CHỈ còn: nạp module, định tuyến message, và khối khởi tạo alarms.
 */

import * as DB from "./db.js";
import { openDashboard } from "./util.js";
import {
  syncSource,
  syncAllSources,
  SEED_PRICE_SOURCE_IDS,
  rememberDeletedSeed,
  pruneLegacySources,
  seedPriceSources,
} from "./prices.js";
import { listSheetTabs, previewSheet, importSheetTabs } from "./sheets.js";
import { discoverSelectors, buildConfigWithAI, listModels, spinPostContent } from "./ai.js";
import {
  generateAdvisories,
  analyzePost,
  approveAdvisory,
} from "./advisory.js";
import {
  startCrawlInActiveTab,
  stopCrawlInActiveTab,
  crawlGroupInTab,
  scanJoinedGroups,
  removeCrawlTab,
  runJob,
  executeDeletePost,
  processDueJobs,
  scheduleTickSoon,
  AUTOCRAWL_ALARM,
  getAutoCrawlConfig,
  applyAutoCrawlConfig,
  processAutoCrawl,
  initAutoCrawl,
  AUTOSYNC_ALARM,
  getAutoSyncConfig,
  applyAutoSyncConfig,
  processAutoSync,
  initAutoSync,
} from "./crawl.js";

// Xử lý message bất đồng bộ: trả true để giữ kênh sendResponse mở.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return false;

  switch (msg.type) {
    case "GET_KNOWN_IDS": {
      DB.getKnownIds(msg.groupId)
        .then((ids) => sendResponse({ ok: true, ids }))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "SAVE_POSTS": {
      DB.savePosts(msg.posts || [])
        .then((res) => sendResponse({ ok: true, ...res }))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "GET_STATS": {
      DB.getStats()
        .then((stats) => sendResponse({ ok: true, stats }))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "GET_ALL_POSTS": {
      DB.getAllPosts(msg.groupId)
        .then((posts) => sendResponse({ ok: true, posts }))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "CLEAR_POSTS": {
      DB.clearPosts(msg.groupId)
        .then((deleted) => sendResponse({ ok: true, deleted }))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "DISCOVER_SELECTORS": {
      discoverSelectors()
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "AI_SPIN_CONTENT": {
      spinPostContent(msg.payload || {})
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "GET_SELECTORS": {
      chrome.storage.local.get("fbSelectors", (r) => {
        sendResponse({ ok: true, selectors: (r && r.fbSelectors) || null });
      });
      return true;
    }

    case "CLEAR_SELECTORS": {
      chrome.storage.local.remove("fbSelectors", () => sendResponse({ ok: true }));
      return true;
    }

    case "START_CRAWL": {
      startCrawlInActiveTab(msg.options || {})
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "STOP_CRAWL": {
      stopCrawlInActiveTab()
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "OPEN_DASHBOARD": {
      openDashboard()
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "GET_GROUPS": {
      DB.getGroups()
        .then((groups) => sendResponse({ ok: true, groups }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SAVE_GROUP": {
      DB.saveGroup(msg.group || {})
        .then((g) => sendResponse({ ok: true, group: g }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "DELETE_GROUP": {
      DB.deleteGroup(msg.groupId)
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SCAN_JOINED_GROUPS": {
      scanJoinedGroups()
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "CRAWL_GROUP": {
      crawlGroupInTab(msg.groupId, msg.options || {})
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "GET_JOBS": {
      DB.getJobs(msg.jobType)
        .then((jobs) => sendResponse({ ok: true, jobs }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "CREATE_JOB": {
      DB.createJob(msg.job || {})
        .then((job) => {
          scheduleTickSoon();
          sendResponse({ ok: true, job });
        })
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "DELETE_JOB": {
      (async () => {
        // Tuỳ chọn: xoá luôn bài trên Facebook nếu có link bài và người dùng đồng ý.
        let remote = null;
        if (msg.deleteRemote && msg.postUrl) {
          remote = await executeDeletePost(msg.postUrl);
        }
        await DB.deleteJob(msg.id);
        sendResponse({ ok: true, remote });
      })().catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "CLEAR_FINISHED_JOBS": {
      DB.clearFinishedJobs()
        .then((deleted) => sendResponse({ ok: true, deleted }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "RUN_JOB_NOW": {
      (async () => {
        const jobs = await DB.getJobs();
        const job = jobs.find((j) => j.id === msg.id);
        if (!job) return sendResponse({ ok: false, error: "Không tìm thấy job." });
        const r = await runJob(job);
        sendResponse(r);
      })().catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "GET_AUTOCRAWL": {
      getAutoCrawlConfig()
        .then((cfg) => sendResponse({ ok: true, config: cfg }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SET_AUTOCRAWL": {
      applyAutoCrawlConfig(msg.config || {})
        .then((cfg) => sendResponse({ ok: true, config: cfg }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "GET_AUTOSYNC": {
      getAutoSyncConfig()
        .then((cfg) => sendResponse({ ok: true, config: cfg }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SET_AUTOSYNC": {
      applyAutoSyncConfig(msg.config || {})
        .then((cfg) => sendResponse({ ok: true, config: cfg }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // ---- Kho của tôi: nhập từ Google Sheet công khai --------------------
    case "SHEET_TABS": {
      listSheetTabs(msg.url || "")
        .then((r) => sendResponse({ ok: true, ...r }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SHEET_PREVIEW": {
      previewSheet(msg.spreadsheetId, msg.gid)
        .then((r) => sendResponse({ ok: true, ...r }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "IMPORT_SHEET": {
      importSheetTabs(msg.spreadsheetId, msg.tabs || [])
        .then((r) => sendResponse({ ok: true, ...r }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // ---- Build cấu hình PC bằng AI --------------------------------------
    case "BUILD_CONFIG": {
      buildConfigWithAI(msg.payload || {})
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // ---- Lấy danh sách model khả dụng từ endpoint ------------------------
    case "LIST_MODELS": {
      listModels()
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // ---- Nguồn dữ liệu giá/sản phẩm -------------------------------------
    case "GET_SOURCES": {
      DB.getSources()
        .then((sources) => sendResponse({ ok: true, sources }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SAVE_SOURCE": {
      DB.saveSource(msg.source || {})
        .then((source) => sendResponse({ ok: true, source }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "DELETE_SOURCE": {
      (async () => {
        await DB.deleteSource(msg.id);
        // Nếu xoá đúng nguồn seed sẵn => ghi nhớ để không tự thêm lại ở lần khởi động sau.
        if (SEED_PRICE_SOURCE_IDS.has(msg.id)) await rememberDeletedSeed(msg.id);
      })()
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // Gọi URL API nội bộ đã cấu hình -> chuẩn hoá -> lưu vào kho sản phẩm.
    case "SYNC_SOURCE": {
      syncSource(msg.id)
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SYNC_ALL_SOURCES": {
      syncAllSources()
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // ---- Sản phẩm -------------------------------------------------------
    case "GET_PRODUCTS": {
      DB.getProducts(msg.source)
        .then((products) => sendResponse({ ok: true, products }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "SEARCH_PRODUCTS": {
      DB.searchProducts(msg.opts || {})
        .then((products) => sendResponse({ ok: true, products }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "CLEAR_PRODUCTS": {
      DB.clearProducts(msg.source)
        .then((deleted) => sendResponse({ ok: true, deleted }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "DELETE_PRODUCT": {
      DB.deleteProduct(msg.productId)
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // ----------------------- TƯ VẤN AI (advisories) ----------------------
    case "GEN_ADVISORIES": {
      generateAdvisories(msg.options || {})
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "GET_ADVISORIES": {
      DB.getAdvisories(msg.status)
        .then((advisories) => sendResponse({ ok: true, advisories }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "UPDATE_ADVISORY": {
      DB.updateAdvisory(msg.postId, msg.patch || {})
        .then((adv) => sendResponse({ ok: true, advisory: adv }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "APPROVE_ADVISORY": {
      approveAdvisory(msg.postId)
        .then((r) => sendResponse(r))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "REJECT_ADVISORY": {
      DB.updateAdvisory(msg.postId, { status: "rejected", rejectedAt: Date.now() })
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "DELETE_ADVISORY": {
      DB.deleteAdvisory(msg.postId)
        .then(() => sendResponse({ ok: true }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    case "CLEAR_ADVISORIES": {
      DB.clearAdvisories(msg.status)
        .then((deleted) => sendResponse({ ok: true, deleted }))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // Phân tích MỘT bài theo yêu cầu (nút "AI phân tích") -> soạn nháp trả lời
    // ngay, KHÔNG lưu sẵn. Người dùng xem rồi tự copy / tạo việc bình luận.
    case "ANALYZE_POST": {
      analyzePost(msg.post || {})
        .then((res) => sendResponse(res))
        .catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    // Content phát tiến độ -> popup/dashboard tự lắng nghe, background không xử lý.
    case "CRAWL_PROGRESS":
      return false;

    // Crawl xong: nếu là tab do background tự mở (chế độ nền / hàng loạt) thì đóng lại,
    // tránh để lại hàng loạt tab rác sau khi crawl nhiều nhóm.
    case "CRAWL_DONE": {
      const tabId = sender && sender.tab && sender.tab.id;
      if (tabId != null) {
        // removeCrawlTab trả true nếu tabId đúng là tab do background tự mở.
        // Đọc từ chrome.storage.session nên vẫn đúng dù SW vừa khởi động lại.
        removeCrawlTab(tabId).then((wasOurs) => {
          if (!wasOurs) return;
          // Chờ một nhịp để content kịp gửi nốt SAVE_POSTS cuối cùng rồi mới đóng tab.
          setTimeout(() => {
            chrome.tabs.remove(tabId, () => void chrome.runtime.lastError);
          }, 1500);
        });
      }
      return false;
    }

    default:
      return false;
  }
});

/* ----------------------- KHỞI TẠO: alarms + seed ----------------------- */

try {
  chrome.alarms.create("jobTick", { periodInMinutes: 1 });
  chrome.alarms.onAlarm.addListener((a) => {
    if (!a) return;
    if (a.name === "jobTick") processDueJobs();
    else if (a.name === AUTOCRAWL_ALARM) processAutoCrawl();
    else if (a.name === AUTOSYNC_ALARM) processAutoSync();
  });
  initAutoCrawl();
  initAutoSync();
  // Dọn nguồn trùng "Linh kiện máy tính" đời cũ TRƯỚC khi seed lại 4 nguồn chuẩn.
  pruneLegacySources().then(() => seedPriceSources());
} catch (e) {}
